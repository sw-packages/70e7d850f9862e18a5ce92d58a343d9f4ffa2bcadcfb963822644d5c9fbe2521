#define PACKAGE_BUGREPORT "http://sourceforge.net/p/winflexbison/tickets"
#define VERSION "3.1"
#define PACKAGE_COPYRIGHT_YEAR 2018
#define LOCALEDIR ""
#define PACKAGE_STRING "bison"
#define PACKAGE_URL "http://sourceforge.net/projects/winflexbison/"
#define PACKAGE ""
#define PACKAGE_VERSION "3.1"
#define PACKAGE_NAME "bison"
#define PKGDATADIR "/tmp/sw/sw.server.tools.fetcher/build/bead-8d6e-0eb3-c204/.sw/src/f8b3f06fe29c/winflexbison-master/bison/data/"
#define RENAME_OPEN_FILE_WORKS 1

#define ssize_t ptrdiff_t
#define inline
//#define const